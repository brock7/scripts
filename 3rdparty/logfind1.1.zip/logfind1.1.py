#!/usr/bin/python
#Uses a list of log files to search
#for existing logs and then checks readability
#with the current user.

#Version 1.1 added ability to search for a string and 
#to output all readable logs to a directory.

#d3hydr8[at]gmail[dot]com 

import sys, os, getpass, re, shutil

print "\n\t   d3hydr8[at]gmail[dot]com LogFinder v1.1"
print "\t---------------------------------------------\n"

if len(sys.argv) not in [2,4,6]:
	print "\nUsage: ./logfind.py <log list> <options>"
	print "Ex: ./logfind.py logs.txt -find 198.162.0.1 -output /home/d3hydr8/logs\n"
	print "\t[options]"
	print "\t   -f/-find <string to search for> : Search for ip, passwords, etc."
	print "\t   -o/-output <directory> : Output readable logs to a directory\n"
	sys.exit(1)
	
for arg in sys.argv[1:]:
	if arg.lower() == "-f" or arg.lower() == "-find":
		string = sys.argv[int(sys.argv[1:].index(arg))+2]
	if arg.lower() == "-o" or arg.lower() == "-output":
		Dir = sys.argv[int(sys.argv[1:].index(arg))+2]
	
try:
  logs = open(sys.argv[1], "r").readlines()
except(IOError): 
  print "Error: Check your loglist path\n"
  sys.exit(1)
print "\n[+] Log Files Loaded:",len(logs),"\n"
try:
	if string:
		print "[+] Search String:",string
except(NameError):
	string = None
	pass
try:
	if Dir:
		os.mkdir(Dir)
		print "[+] Directory Created:",Dir,"\n"
except(NameError):
	Dir = None
	pass
except(OSError):
	print "[-] Error Creating Dir. Might already exist\n"
xlogs = []
for log in logs:
	if os.path.isfile(log[:-1]) == True:
		print "[+] Found:",log[:-1]," Size:",os.path.getsize(log[:-1])
		try:
			f = open(log[:-1], "r").readlines()
			if string != None:
				num = 1
				for line in f:
					if re.search(string, line[:-1]):
						print "\n[!] String Found:",log[:-1]," Line:",num
						print "[!] Line:",line
					num +=1
			xlogs.append(log[:-1])
		except(IOError):
			print "[-] Not Readable by",getpass.getuser()
if Dir != None and len(xlogs) >= 1:
	print "\n[+] Transferring ",len(xlogs),"logs to",Dir,"..."
	for log in xlogs:
		try:
			shutil.copy(log, Dir)
		except(IndexError):
			print "[-] Copy Error:",log
else:
	print "[-] No directory or logs found" 
	
print "\n[+] Done\n"



	
	



